<?php
namespace Sfgz\SfgzFoyer\Task;
 
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Scheduler\Task\AbstractTask;

 /** 
 * Class CalendarImportTask
 * imports Belegungen from calendar raumplanung
 * 
 * 
 */
 
class CalendarImportTask extends AbstractTask {
    
	public function execute(){
            $this->objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
            $flashMessageService = $this->objectManager->get(\TYPO3\CMS\Core\Messaging\FlashMessageService::class);
            $this->messageQueue = $flashMessageService->getMessageQueueByIdentifier();
            
            $this->calendarService = GeneralUtility::makeInstance('Sfgz\\SfgzFoyer\\Service\\CalendarService');
            $this->calendarService->extConf['calendar_max_age_minutes'] = 0;
            $db = $this->calendarService->calendarsReadData() ;
            
			// create flashMessage
			$message = GeneralUtility::makeInstance(
					'TYPO3\\CMS\\Core\\Messaging\\FlashMessage',
					count($db) . ' Einträge wurden importiert.',
					'Importiert', 
					count($db) ? \TYPO3\CMS\Core\Messaging\FlashMessage::OK : \TYPO3\CMS\Core\Messaging\FlashMessage::INFO
			);
			$this->messageQueue->addMessage($message);
			
			return true;
	}


}
