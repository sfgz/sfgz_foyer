<?php
namespace Sfgz\SfgzFoyer\Domain\Repository;


use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Persistence\Generic\Typo3QuerySettings;

/***
 *
 * This file is part of the "Foyer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Daniel Rueegg <daten@verarbeitung.ch>
 *
 ***/
/**
 * The repository for Infos
 */
class InfoRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    /**
     * @var array
     */
    protected $defaultOrderings = array(
        'datum_anzeige' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
    );
    
    /**
     * Always return hidden and deleted records from this Repository
     */
    public function initializeObject()
    {
        // Load the querySettings
        $querySettings = $this->objectManager->get(Typo3QuerySettings::class);

        // Ignore hidden and deleted records
        $querySettings
            ->setIgnoreEnableFields(true)
            ->setIncludeDeleted(true);

        // Set your settings as default for the entire Repository
        $this->setDefaultQuerySettings($querySettings);
    }
    
    /**
     * Find a record by DatumAnzeige even if it is hidden or deleted
     *
     * @param string $strDate
     * @return object
     */
    public function findHiddenByDatumAnzeige( $strDate )
    {
        $query = $this->createQuery();

        // Here you enable the hidden and deleted Records
        $query->getQuerySettings()
            ->setIgnoreEnableFields(true)
            ->setIncludeDeleted(true);

        // Your query
        $query->matching($query->equals('datum_anzeige', $strDate));
        return $query->execute();
    }
    
    /**
     * Find a record by uid even if it is hidden or deleted
     *
     * @return object
     */
    public function findHiddenAll()
    {
        $query = $this->createQuery();

        // Here you enable the hidden and deleted Records
        $query->getQuerySettings()
            ->setIgnoreEnableFields(true)
            ->setIncludeDeleted(true);

        return $query->execute();
    }

    /**
     * Find a record by uid even if it is hidden or deleted
     *
     * @param int $uid
     * @return object
     */
    public function findHiddenByUid($uid)
    {
        $query = $this->createQuery();

        // Here you enable the hidden and deleted Records
        $query->getQuerySettings()
            ->setIgnoreEnableFields(true)
            ->setIncludeDeleted(true);

        // Your query
        $query->matching($query->equals('uid', $uid));
        return $query->execute()->getFirst();
    }    
}
