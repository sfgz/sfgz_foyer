## lib.reload
## reload the page only if is set in settings.reload_page
lib.foyer_reload_display = TEXT
lib.foyer_reload_display.value = 1000*{$plugin.tx_sfgzfoyer_main.settings.reload_page}
lib.foyer_reload_display.prioriCalc = 1
lib.foyer_reload_display.wrap = reloadClockPage( | );

## clock
lib.foyer_clock = COA_INT

## preview text for clock
lib.foyer_clock.12 = COA_INT
lib.foyer_clock.12 {
    wrap = <div style="text-align:center;margin-top:-22px;padding:0 0 3px 0;font-size:smaller;">&nbsp;|</div>
    10 = TEXT
    10 {
        required = 1
        noTrimWrap = | {GP:datum} | |
        wrap = &nbsp;|&nbsp;Uhr
        value = {GP:zeit}
        insertData = 1
    }
}
[request.getPageArguments().get('zeit') == '']
    lib.foyer_clock.12.10.wrap >
[global]
[request.getPageArguments().get('zeit') == ''] && [request.getPageArguments().get('datum') == '']
    lib.foyer_clock.12 >
[global]

## body and wrap for the clock
lib.foyer_clock.22 = TEXT
lib.foyer_clock.22 {
    value (
        <article class="clock ">
        <div class="hours-container">
            <div class="hours"></div>
        </div>
        <div class="minutes-container">
            <div class="minutes"></div>
        </div>
        <div class="seconds-container">
            <div class="seconds"></div>
        </div>
        </article>
    )
    wrap = <div class="clockframe">|</div>
    noTrimWrap = |<!-- lib.foyer_clock uses php-time -->||
}
## set the station_design
[globalVar = LIT:0<{$plugin.tx_sfgzfoyer_main.settings.station_design}]
    lib.foyer_clock.22.wrap = <div class="clockframe station">|</div>
[global]

## comment in the document about whether we use PHP or JS time
[globalVar = LIT:0<{$plugin.tx_sfgzfoyer_main.settings.use_js_time_in_clock}]
    lib.foyer_clock.22.noTrimWrap = |<!-- lib.foyer_clock uses js-time -->||
[global]

## abort - link
lib.foyer_clock.32 = TEXT
lib.foyer_clock.32 { 
    value = Vorschau abbrechen &larr;
    typolink.parameter = _self
    typolink.parameter.data=TSFE:id 
    typolink.title = Vorschau abbrechen
    wrap = <div style="font-size:smaller;text-align:center;">|</div>
}
[request.getPageArguments().get('zeit') == ''] && [request.getPageArguments().get('datum') == '']
    lib.foyer_clock.32 >
[global]


## CSS for the clock
plugin.tx_sfgzkurs_clock._CSS_DEFAULT_STYLE (
	.clockframe {
		margin:auto;
		width: 167px;
		height:167px;
		padding:12px 10px 10px 12px;
		border-radius:50%;
		border:3px solid #009ee0;
	}

	.clockframe.station {
		width:167px;
		height: 167px;
		padding:0px 0 0 0px;
		border:2px solid #333;
	}

	.clock {
		border-radius: 50%;
		background: #fff url({$plugin.sfgz_design.settings.baseURL}typo3conf/ext/sfgz_kurs/Resources/Public/Icons/ios_clock.svg) no-repeat center;
		background-size: 95%;
		height: 100%;
		position: relative;
		width: 100%;
		margin:0;
	}
	.station .clock {
		background: #fff url({$plugin.sfgz_design.settings.baseURL}typo3conf/ext/sfgz_kurs/Resources/Public/Icons/station_clock.svg) no-repeat center;
	}

	.clock:after {
		background: #000;
		border-radius: 50%;
		content: "";
		position: absolute;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
		width: 5%;
		height: 5%;
		z-index: 3;
	}
	.station .clock:after {
		background: #009ee0;
	}

	.minutes-container, .hours-container, .seconds-container {
		position: absolute;
		top: 0;
		right: 0;
		bottom: 0;
		left: 0;
		overflow:hidden;
	}
	.station .minutes-container {
			/* this let the minutes-hand jump on 0 Minutes */
			/* transition: transform 0.3s cubic-bezier(.4,2.08,.55,.44); */
	}
	.station .seconds-container {
			/* this let the seconds-hand jump on 0 Seconds */
			/* transition: transform 0.2s cubic-bezier(.4,2.08,.55,.44); */
	}
	.hours {
		background: #000;
		width: 3.5%;
		height: 40%;
		position: absolute;
		left: 48.25%;
		top: 22%;
		transform-origin: 50% 71%;
	}

	.minutes {
		background: #000;
		width: 3.5%;
		height: 55%;
		position: absolute;
		left: 48.25%;
		top: 7%;
		transform-origin: 50% 78.5%;
	}
	.station .minutes {
		height: 45%;
		top: 15%;
	}

	.seconds {
		background: #000;
		width: 1.5%;
		height: 42%;
		position: absolute;
		left: 49.25%;
		top: 20%;
		transform-origin: 50% 71%;
		z-index: 80;
	}
	.station .seconds {
		background: #009ee0;
	}

	@keyframes rotate {
		100% {
			transform: rotateZ(360deg);
		}
	}
)
