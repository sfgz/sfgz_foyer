		// extension sfgzdisplay_main: functions for Info->editorAction
		function foyerAppendRaumplanungRow( planUid ) {

			var added = localStorage.getItem( 'belegungen' );
			if( added == 0 ){
				added = 1;
			}else{
				added++;
			}
			localStorage.setItem('belegungen' , added );
			
			if( planUid ){
				var zeit_von  = $( '#raum_' + planUid + '_zeit_von' ).html();
				var zeit_bis  = $( '#raum_' + planUid + '_zeit_bis' ).html();
				var titel = $( '#raum_' + planUid + '_titel' ).html();
				var zimmer = $( '#raum_' + planUid + '_zimmer' ).html();
				var mieter = $( '#raum_' + planUid + '_mieter' ).html();
			}else{
				var zeit_von  = '';
				var zeit_bis  = '';
				var titel = '';
				var zimmer = '';
				var mieter = '';
			}

			var buttonCell = '<td class="arrowleft pointer" onClick="$(\'#pln_' +  added + '\').remove();"> </td>';
			var raumCell = '<td><input type="text" value="' +  zimmer + '" name="tx_sfgzdisplay_main[belegung][pln_' +  added + '][raum]" size="6" /></td>';
			var timeCells = '<td>';
			timeCells = timeCells + '<input type="text" value="' +  zeit_von + '" name="tx_sfgzdisplay_main[belegung][pln_' +  added + '][zeitVon]" size="3" /> ';
			timeCells = timeCells + '</td><td>';
			timeCells = timeCells + '<input type="text" value="' +  zeit_bis + '" name="tx_sfgzdisplay_main[belegung][pln_' +  added + '][zeitBis]" size="3" />';
			timeCells = timeCells + '</td>';
			var textCell = '<td><input type="text" value="' +  titel + '" name="tx_sfgzdisplay_main[belegung][pln_' +  added + '][belegungstext]" size="30" /></td>';
			var personCell = '<td><input type="text" value="' +  mieter + '" name="tx_sfgzdisplay_main[belegung][pln_' +  added + '][person]" size="20" /></td>';
			
			$(".belegungen tbody").append('<tr id="pln_' + added + '">' + buttonCell + timeCells + raumCell + textCell + personCell + "</tr>");
		}
		
