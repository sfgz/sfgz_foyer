        // extension sfgz_foyer: handle register-tabs. events for REGISTERS
        // display tab when click or simulate-click on register-tab 
        // registermap_id = #hauptregister
        function registerTabChange( tab , registermap_id ) {
            // contents: remove all div with class register_inhalt, then add specific by id
            $( '#' + registermap_id + ' div.register_inhalt').hide();
            
            $( '#' + tab ).show();
            // contents: add child elements  with own form-wrap
            $( '#' + registermap_id + ' .child_of_' + tab ).show();
            // register-tabs: remove selected on all tabs, then append on one specific tab by class
            $( '#' + registermap_id + ' UL.register LI' ).removeClass( 'selected' );
            $( '#' + registermap_id + ' UL.register LI.' + tab ).addClass( 'selected' );
        }

        // store tab-name when click on register-tab 
        function storeActualRegisterTabName( tab ) {
            var registermap_id = $( 'li.' + tab ).closest( 'div.registermap' ).prop( 'id' );
            var formname = formnameFromRegisterId( registermap_id );
            localStorage.setItem('registerpage_' + registermap_id + '_' + formname , tab );
        }

        // get tab-name 
        function actualRegisterTabName( registermap_id ) {
            var formname = formnameFromRegisterId( registermap_id );
            var tab = localStorage.getItem( 'registerpage_' + registermap_id + '_' + formname );
            return tab;
        }

        // get form-name 
        function formnameFromRegisterId( registermap_id ) {
            // if there is no form, use upper div-id as formname 
            var formname = $( '#' + registermap_id ).closest( 'form' ).prop( 'name' );
            if( formname ){
                return formname;
            }
            formname = $( '#' + registermap_id ).closest( 'div' ).prop( 'id' );
            return formname;
        }
        
        $(document).ready(function(){
    
                // events for REGISTERS
                // bind click-event with registerTab-setter
                $('div.registermap UL.register LI' ).on( 'click', function() {
                    registermap_id = $( this ).closest( 'div' ).prop( 'id' ); // #hauptregister
                    // detect the class, that for first remove class 'selected' if set
                    $( this ).removeClass('selected');
                    var tab = $( this ).attr('class');
                    if( tab ){
                        registerTabChange( tab , registermap_id ); 
                        storeActualRegisterTabName( tab ); 
                    }
                });
                // choose tab after page-loading (trigger the klick)
                $( "div.registermap" ).each(function( index ) {
                        var tab = actualRegisterTabName( this.id );
                        if( $('#' + tab ).length ){
                            registerTabChange( tab , this.id );
                        } else {
                            $( '#' + this.id + ' UL.register LI' ).first().trigger( 'click' );
                        }
                });
    
        });
 
