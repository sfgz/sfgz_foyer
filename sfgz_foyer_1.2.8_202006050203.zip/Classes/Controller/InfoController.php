<?php
namespace Sfgz\SfgzFoyer\Controller;

use \TYPO3\CMS\Core\Utility\GeneralUtility;
use \TYPO3\CMS\Core\Utility\ExtensionManagementUtility;

/***
 *
 * This file is part of the "Foyer" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Daniel Rueegg <daten@verarbeitung.ch>
 *
 ***/
/**
 * InfoController
 */
class InfoController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * msg
     * 
     * @var array
     */
    Public $msg = [];

    /**
     * infoRepository
     * 
     * @var \Sfgz\SfgzFoyer\Domain\Repository\InfoRepository
     * @inject
     */
    protected $infoRepository = null;

    /**
        * belegungRepository
        *
        * @var \Sfgz\SfgzFoyer\Domain\Repository\BelegungRepository
        */
    protected $belegungRepository = null;

    /**
        * initializeAction
        *
        */
    public function initializeAction()
    {
        $extKey = \TYPO3\CMS\Core\Utility\GeneralUtility::camelCaseToLowerCaseUnderscored( $this->extensionName );
        $uploadFolder = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName( 'uploads/tx_' . str_replace( '_' , '' , $extKey )  ) . '/' ;
        $this->settings['uploadFolder'] = $uploadFolder;
        
        $this->dateUtility = GeneralUtility::makeInstance('Sfgz\\SfgzFoyer\\Utility\\DateUtility');
        $this->recordsUtility = GeneralUtility::makeInstance('Sfgz\\SfgzFoyer\\Utility\\RecordsUtility');

        $this->recordsUtility->setSettings( $this->settings );

        $objectManager = GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
        $this->persistenceManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager');

        $querySettings = $objectManager->get('TYPO3\CMS\\Extbase\\Persistence\\Generic\\Typo3QuerySettings');
        $querySettings->setRespectStoragePage(FALSE);
        $querySettings->setIgnoreEnableFields(TRUE);

        $this->infoRepository = $objectManager->get('Sfgz\\SfgzFoyer\\Domain\\Repository\\InfoRepository');
        $this->infoRepository->setDefaultQuerySettings($querySettings);
        
        $this->belegungRepository = $objectManager->get('Sfgz\\SfgzFoyer\\Domain\\Repository\\BelegungRepository');
        $this->belegungRepository->setDefaultQuerySettings($querySettings);

        $this->fileUtility = GeneralUtility::makeInstance('Sfgz\\SfgzFoyer\\Utility\\FileUtility');
        
        $this->fileUtility->setVariables( [ 
            'smlExtKey' => str_replace( '_' , '' , $extKey ) ,  
            'pluginName' => \TYPO3\CMS\Core\Utility\GeneralUtility::camelCaseToLowerCaseUnderscored($this->request->getPluginName()) ,  
            'dateiname' => 'dateiname' ,  
            'uploadFolder' => $uploadFolder ,  
        ]);

        $extensionConfig = GeneralUtility::makeInstance( \TYPO3\CMS\Core\Configuration\ExtensionConfiguration::class ); 
        $this->extConf = $extensionConfig->get('sfgz_foyer');
        $this->settings['belegung_age_in_days'] = $this->extConf['belegung_age_in_days'];
        $this->settings['belegung_age_in_daysMinus1'] = $this->extConf['belegung_age_in_days']-1;
    }

    /**
     * action display
     * 
     * @return void
     */
    public function displayAction()
    {
        $zeitFromExtern = GeneralUtility::_GET('zeit');
        $datumFromExtern = GeneralUtility::_GET('datum');
        if($datumFromExtern){
            $strStichtag = $datumFromExtern;
            if( empty($zeitFromExtern) ) $zeitFromExtern = '00:00' ;
            
        }else{
            $strStichtag = '';
        }
        
        if( $strStichtag ){ // other date
            $objDate = $this->dateUtility->sanitizeMixedDateTimestringToObject( $strStichtag );
        }else{ // today
            $objDate = $this->dateUtility->sanitizeDateTimestamp();
        }

        $objInfo = $this->recordsUtility->findInfoByDatumAnzeige( $objDate->format('Y-m-d') );
        $aLektionen = $this->recordsUtility->findBelegungenAndLektionenByDatumAnzeige( $objDate->format('Y-m-d') );
        
        $aPermacontent = $this->recordsUtility->findPermaInfoByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        
        $aLektionen = $this->enrichLektionenWithCss( $aLektionen , $aPermacontent , $zeitFromExtern );
        
        $aCallState = [ 
                'standalone' => $this->request->hasArgument('action') ? 0 : 1 , 
                'preview'    => $this->request->hasArgument('stichtag') || $datumFromExtern || $zeitFromExtern ? 1 : 0,
                'zeit'       => $zeitFromExtern ? $zeitFromExtern : ''
        ];
        
        $this->view->assign('stichtag', $objDate);
        $this->view->assign('info', $objInfo);
        $this->view->assign('lektionen', $aLektionen );
        $this->view->assign('callstate', $aCallState );
        $this->view->assign('permacontent', $aPermacontent);
    }

    /**
     * action vorschau
     * 
     * @return void
     */
    public function vorschauAction()
    {
        if( $this->request->hasArgument('stichtag') ){
            $stichtag = $this->request->getArgument('stichtag');
        }elseif( $this->request->hasArgument('add_stichtag') || $this->request->hasArgument('sub_stichtag') ) {
                    $dateString = $this->dateUtility->getStichtag();
                    $dateObject = $this->dateUtility->sanitizeMixedDateTimestringToObject( $dateString );
                    if($this->request->hasArgument('add_stichtag')){
                        $dateObject->add(new \DateInterval('P1D'));
                    }else{
                        $dateObject->sub(new \DateInterval('P1D'));
                    }
                    $stichtag = $dateObject->format('d.m.Y');
                    $this->dateUtility->storeStichtag($stichtag);
                    $GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
        }else{
                $stichtag = $this->dateUtility->getGermanStichtag();
        }
        // create DateTime object 
        if( $stichtag ){ // other date
            $objDate = $this->dateUtility->sanitizeMixedDateTimestringToObject( $stichtag );
        }else{ // today
            $objDate = $this->dateUtility->sanitizeDateTimestamp();
        }
        $this->view->assign('stichtag', $objDate );

        $aPermacontent = $this->recordsUtility->findPermaInfoByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        $this->view->assign('permacontent', $aPermacontent);
        
        $aLektionen = $this->recordsUtility->findBelegungenAndLektionenByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        $aLektionen = $this->enrichLektionenWithCss( $aLektionen , $aPermacontent );
        $this->view->assign('lektionen', $aLektionen);
        $objInfo = $this->recordsUtility->findInfoByDatumAnzeige( $objDate->format('Y-m-d') );
        $this->view->assign('info', $objInfo);
    }

    /**
     * action editor
     * 
     * @return void
     */
    public function editorAction()
    {
        $stichtag = $this->dateUtility->getGermanStichtag();
        $this->view->assign('stichtag', $stichtag);

        $objDate = $this->dateUtility->sanitizeMixedDateTimestringToObject( $stichtag );
        $this->msg[] = $objDate->format( 'd.m.Y H:i:s' );
        // main object info with belegung on iBelegung
        $aObjInfo = $this->findOrCreateInfoByDate( $objDate );
        $this->view->assign('info', $aObjInfo);

        $this->view->assign('objStichtag', $objDate);
        
        $aPermacontent = $this->recordsUtility->findPermaInfoByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        $this->view->assign('permacontent', $aPermacontent);
        
        $unixTime = $aObjInfo->getDatumPerma();
//         $gTime = $unixTime ? date( 'd.m.Y' , $unixTime ): '';
       $this->view->assign('datum_perma', $unixTime );

        if( ExtensionManagementUtility::isLoaded('sfgz_kurs') ){
            $this->view->assign('isKursLoaded', true );
        }else{
            $this->view->assign('isKursLoaded', false );
        }
       
        $aLektionen = $this->recordsUtility->findBelegungenAndLektionenByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        $aCssLektionen = $this->enrichLektionenWithCss( $aLektionen , $aPermacontent );
        $this->view->assign('lektionen', $aCssLektionen);
        
        $aVorgabeBelegungen = $this->recordsUtility->findRaumplanungByDatumAnzeige( $objDate->format( 'Y-m-d' ) );
        $this->view->assign('raumplanung', $aVorgabeBelegungen ); // $errors = $this->dataSourcesService->errors ;

        $this->settings['infodisplay_hideLessonsAfterMinutesSigned'] = $this->settings['infodisplay_hideLessonsAfterMinutes'] < 0 ? ( $this->settings['infodisplay_hideLessonsAfterMinutes'] * -1 ): $this->settings['infodisplay_hideLessonsAfterMinutes'];
        $this->view->assign('settings', $this->settings );
        
        $aFiles = $this->fileUtility->show_file_list( 'suggest' );
        $this->view->assign('filelist', $aFiles );

//         $this->deleteInfoAndBelegungOlderThanDate(); done with sheduler task
        
        if( count($this->recordsUtility->msg) ){
            $this->msg = $this->recordsUtility->getMessages( $this->recordsUtility , $this );
        }
        ksort($this->msg);
        $this->view->assign('msg', $this->msg );
        $debug = [];
        if( $this->request->hasArgument('debug') ) $debug  = $this->request->getArgument('debug');
        $this->view->assign('debug', $debug );
    }
	
	/**
	 * Initialize  update
	 *
	 * @return void
	 */
	public function initializeUpdateAction() {
        
 		$args = $this->arguments['info']->getPropertyMappingConfiguration();

		if($this->request->hasArgument('info')) {
			$info = $this->request->getArgument('info');
            $this->arguments->getArgument('info')->getPropertyMappingConfiguration()->skipProperties('datum_perma');
			if(!empty($info['datum_perma'])) {
                $args->forProperty('datum_perma')->setTypeConverterOption('TYPO3\\CMS\\Extbase\\Property\\TypeConverter\\DateTimeConverter', \TYPO3\CMS\Extbase\Property\TypeConverter\DateTimeConverter::CONFIGURATION_DATE_FORMAT, 'd.m.Y');
			}
        }

    }

    /**
     * action update
     * 
        * @param \Sfgz\SfgzFoyer\Domain\Model\Info $info
     * @return void
     */
    public function updateAction(\Sfgz\SfgzFoyer\Domain\Model\Info $info=NULL)
    {
        // changed date by input and button pressed
        if( $this->request->hasArgument('but_stichtag') ) {
                    //change or delete stichtag
                    $incomedStichtag = $this->request->hasArgument('stichtag') ? $this->request->getArgument('stichtag') : '';
                    $this->dateUtility->storeStichtag($incomedStichtag);
        }
        // changed date by a arrow-button
        if( $this->request->hasArgument('add_stichtag') || $this->request->hasArgument('sub_stichtag') ) {
                    $dateString = $this->dateUtility->getStichtag();
                    $dateObject = $this->dateUtility->sanitizeMixedDateTimestringToObject( $dateString );
                    if($this->request->hasArgument('add_stichtag')){
                        $dateObject->add(new \DateInterval('P1D'));
                    }else{
                        $dateObject->sub(new \DateInterval('P1D'));
                    }
                    $incomedStichtag = $dateObject->format('d.m.Y');
                    $this->dateUtility->storeStichtag($incomedStichtag);
        }
 
        // example: create or download example-belegungen-file
        if( $this->request->hasArgument('download') ){
                $filename = $this->request->getArgument('download');
                $this->fileUtility->downloadFile( $this->settings['uploadFolder'] . 'suggest/' . $filename , $filename);
                $this->addFlashMessage('Datei nicht heruntergeladen: suggest/' . $filename . ' vorhanden: ' . file_exists($this->settings['uploadFolder'] . 'suggest/' . $filename) , 'Download', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
        }
        if( $this->request->hasArgument('example') ){
                $filename = 'suggest/example.csv';
                $stichtag = $this->dateUtility->getStichtag();
                $inhalt = $this->recordsUtility->getRaumplanungExample($stichtag);
                file_put_contents( $this->settings['uploadFolder'] .  $filename , $inhalt );
                if( count($this->recordsUtility->msg) ){
                    $this->msg = $this->recordsUtility->getMessages( $this->recordsUtility , $this );
                }
        }
        
        // upload or delete belegungen-file
        if ( $this->request->hasArgument('submit') ){
                $submit = $this->request->getArgument('submit');
                if( isset($submit['upload']) && $this->request->hasArgument('dateiname') ){
                    $filename = $this->fileUtility->fileUpload( 'suggest' );
                    if($filename) $this->addFlashMessage('Hochgeladen: ' . pathinfo( $filename, PATHINFO_BASENAME ) . '' , 'Upload', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                    if($this->fileUtility->messages) $this->addFlashMessage('' . implode(',',$this->fileUtility->messages) . '' , 'Keine Datei hochgeladen', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
                }elseif(isset($submit['remove'])){
                    $result = $this->fileUtility->remove_file( 'suggest/' . $submit['remove'] );
                    if( $result ){
                        $this->addFlashMessage('' . $submit['remove'] . '' , 'Datei gelöscht', \TYPO3\CMS\Core\Messaging\AbstractMessage::WARNING);
                    }else{
                        $this->addFlashMessage('Die Datei »' . $submit['remove'] . '« konnte nicht gelöscht werden' , 'Datei löschen', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
                    }
                }
        }
       
        // store info and belegung
        if ( $this->request->hasArgument('but_store') ){
            if ( !$info ){
                    // ?? HELP !! //
                    $this->addFlashMessage('NICHT gespeichert. Unbekannter Fehler.' , 'Programmfehler (Bug)', \TYPO3\CMS\Core\Messaging\AbstractMessage::ERROR);
            }else{
                    if ( $this->request->hasArgument('info') ){
                        $i =$this->request->getArgument('info');
                        if( isset($i['datum_perma']) ){
                            if( !empty($i['datum_perma']) ){
                                    $objDate = $this->dateUtility->sanitizeMixedDateTimestringToObject( $i['datum_perma'] );
                                    $info->setDatumPerma($objDate);
                            }else{
                                // datum_perma is set and is empty: set datum_perma to empty. repository changed for that!
                                $info->setDatumPerma('');
                            }
                        }
                    }
                    // store 
                    $this->infoRepository->update($info);

//                     $options = GeneralUtility::_GET('tx_sfgzdisplay_main');
                    $aBelegungen = $this->request->hasArgument('belegung') ? $this->request->getArgument('belegung'): [];
                    $aBelegungenJs = $_REQUEST['tx_sfgzdisplay_main']['belegung'];
                    if( $aBelegungenJs ) {
                        foreach($aBelegungenJs as $i => $rs ) $aBelegungen[$i] = $rs;
                    }
                    // id is numeric or format 'pln_' . $uid
                    $this->updateBelegungen( $aBelegungen , $info );
                    $this->addFlashMessage('Gespeichert Nr. ' . $info->getUid() , 'OK gespeichert', \TYPO3\CMS\Core\Messaging\AbstractMessage::OK);
                    $GLOBALS['TSFE']->clearPageCacheContent_pidList($GLOBALS['TSFE']->id);
            }
        }
        
        ksort($this->msg);
        $this->view->assign('msg', $this->msg );
        $this->redirect('editor', 'Info', NULL, [ 'debug' => $options]);
    }

    /**
        * enrichLektionenWithCss
        *
        * @param array $aLektionen
        * @param array $aPermacontent
        * @param string $zeit optional, default is now
        * @return array
        */
    public function enrichLektionenWithCss( $aLektionen , $aPermacontent , $zeit ='' )
    {
        if( !count( $aLektionen ) ) return $aLektionen;
        
        $displayed = 0;
        foreach( $aLektionen as $i => $rs ){
            if( $aPermacontent['hideType'][2] ) {
//                 unset($aLektionen[$i]);
                $aLektionen[$i]['display'] = 0;
            }elseif( $aPermacontent['hideType'][1] && $rs['source'] == 'lektion' ) {
//                 unset($aLektionen[$i]);
                $aLektionen[$i]['display'] = 0;
            }else{
                $aLektionen[$i]['display'] = 1;
                $displayed += 1;
            }
        }
        
        if( $zeit ){
            $aTime = explode( ':' , str_replace( '.' , ':' , $zeit ) );
            if( empty($aTime[0]) ) $aTime[0] = 0;
            if( empty($aTime[1]) ) $aTime[1] = 0;
            $nowMinutesFromMidnight = ( $aTime[0] * 60 ) + $aTime[1];
            
        }else{
            $objDateNow = $this->dateUtility->sanitizeDateTimestamp();
            $nowMinutesFromMidnight = ( $objDateNow->format('H') * 60 ) + $objDateNow->format('i');
        }
        $isPassed = [];
        $counter = 0;
        foreach( $aLektionen as $ix => $lektion ){
            if($lektion['display']) $counter +=1;
            
            $aLektionen[$ix]['zeitVon'] = str_replace(':','.',$aLektionen[$ix]['zeitVon']);
            $aLektionen[$ix]['zeitBis'] = str_replace(':','.',$aLektionen[$ix]['zeitBis']);
            
            if( empty($this->settings['infodisplay_hideLessonsAfterMinutes']) ){
                // if 0 = infodisplay_hideLessonsAfterMinutes then leave the loop and display the lesson
                 continue;
            }
            
            $aBis = explode( ':' , str_replace( '.' , ':' , $lektion['zeitBis'] ) );
            $std = is_numeric($aBis[0]) ? ( $aBis[0] * 60 ) : 0;
            $min = is_numeric($aBis[1]) ?  $aBis[1]: 0;
            $lessonMinutesFromMidnight = $min + $std;
            $isPassed[$ix] = $lessonMinutesFromMidnight + $this->settings['infodisplay_hideLessonsAfterMinutes'] < $nowMinutesFromMidnight ? 1 : 0;
            $aLektionen[$ix]['css'] = $isPassed[$ix] ? 'passed' : '';
        }
        $countVisible = $counter - array_sum($isPassed);
        return [ 'daten' => $aLektionen , 'count' => $countVisible , 'displayed' => $displayed ];
    }

    /**
        * findOrCreateInfoByDate();
        * finds info recordset OR or create a new info
        *
        * @param \DateTime $objDate
        * @return \Sfgz\SfgzFoyer\Domain\Model\Info
        */
    Private function findOrCreateInfoByDate( $objDate )
    {
        $this->msg[substr( hrtime(true) , -12)] = '1. Lookfor ' . $objDate->format( 'Y-m-d' );
        
        $existingObject = $this->recordsUtility->findInfoByDatumAnzeige( $objDate->format( 'Y-m-d' ) , '1. InfoController->findOrCreateInfoByDate()' );
        
        if( !$existingObject ){
            $existingObject = GeneralUtility::makeInstance('Sfgz\SfgzFoyer\Domain\Model\Info');
            $existingObject->setDatumAnzeige( $objDate );
            $this->infoRepository->add($existingObject);
            $this->persistenceManager->persistAll();
            
            $this->msg[substr( hrtime(true) , -12)] = '2a. Created ' . $objDate->format( 'Y-m-d' );
            
            $testObject = $this->recordsUtility->findInfoByDatumAnzeige( $objDate->format( 'Y-m-d' ) , '2. InfoController->findOrCreateInfoByDate()' );
            $msg = $testObject ? $testObject->getDatumAnzeige()->format( 'Y-m-d' ) : 'noObject';
            $this->msg[substr( hrtime(true) , -12)] = '3. SecondLookup  is Object?: ' . ($testObject ? 'yes' : 'no') . ' ' . $msg;
            
        }else{
            $this->msg[substr( hrtime(true) , -12)] = '2b. Found ' . $objDate->format( 'Y-m-d' );
        }
        return $existingObject;
    }

    /**
        * updateBelegungen
        *
        * @param array $aBelegungen
        * @param \Sfgz\SfgzFoyer\Domain\Model\Info $info
        * @return \Sfgz\SfgzFoyer\Domain\Model\Info
        */
    Private function updateBelegungen( array $aBelegungen , $info )
    {
        
        $this->deleteBelegungen( $aBelegungen , $info );
       
        // add or store belegungen
        if( !count($aBelegungen) ) return false;
        
        $uidInfo = $info->getUid();
        foreach( $aBelegungen as $ix => $aBelegung ){
            $isNew = substr( $ix , 0 , 4 ) == 'pln_' ? 1 : 0;
            
            if( $isNew ){
                // create recordset
                $objBelegung = GeneralUtility::makeInstance('Sfgz\SfgzFoyer\Domain\Model\Belegung');
            }else{
                // select recordset to update
                $objBelegung = $this->belegungRepository->findByUid($ix);
                if( !$objBelegung ) continue;
            }
            
            $objBelegung->setInfo( $uidInfo );
            $objBelegung->setZeitVon( $aBelegung['zeitVon'] ? sprintf( '%05s' , $aBelegung['zeitVon'] ) : $aBelegung['zeitVon'] );
            $objBelegung->setZeitBis( $aBelegung['zeitBis'] ? sprintf( '%05s' , $aBelegung['zeitBis'] ) : $aBelegung['zeitBis'] );
            $objBelegung->setRaum( $aBelegung['raum'] );
            $objBelegung->setBelegungstext( $aBelegung['belegungstext'] );
            $objBelegung->setPerson( $aBelegung['person'] );
            
            if( $isNew ){
                //  add created recordset to belegungRepository
                $this->belegungRepository->add($objBelegung);
            }else{
                // update existing recordset
                $this->belegungRepository->update($objBelegung);
            }
            $this->persistenceManager->persistAll();
        }

        return true;
    }

    /**
        * deleteBelegungen
        *
        * @param array $aExcludeBelFromDel Do not delete if listed in here as $aExcludeBelFromDel[ uid ]
        * @param \Sfgz\SfgzFoyer\Domain\Model\Info $info
        * @return \Sfgz\SfgzFoyer\Domain\Model\Info
        */
    Private function deleteBelegungen( array $aExcludeBelFromDel , \Sfgz\SfgzFoyer\Domain\Model\Info $info )
    {
        // remove existing belegungen if missed in the array $aExcludeBelFromDel
        $objsBelegungen = $info->getIBelegungen() ;
        if( !count($objsBelegungen) ) return false;
        
        foreach( $objsBelegungen as $ix => $objBelToDel ){
            if( isset( $aExcludeBelFromDel[$objBelToDel->getUid()] ) )  continue;
            $this->belegungRepository->remove($objBelToDel);
            $this->persistenceManager->persistAll();
        }

        return true;
    }
}
