<?php
return [
    'ctrl' => [
        'title' => 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgzfoyer_domain_model_info',
        'label' => 'datum_anzeige',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'enablecolumns' => [
        ],
        'searchFields' => 'infotext',
        'iconfile' => 'EXT:sfgz_foyer/Resources/Public/Icons/tx_sfgzfoyer_domain_model_info.gif'
    ],
    'interface' => [
        'showRecordFieldList' => 'datum_anzeige, datum_perma, hide_perma, infotext, i_belegungen',
    ],
    'types' => [
        '1' => ['showitem' => 'datum_anzeige, datum_perma, hide_perma, infotext, i_belegungen'],
    ],
    'columns' => [
        'datum_anzeige' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgzfoyer_domain_model_info.datum_anzeige',
            'config' => [
                'dbType' => 'date',
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 12,
                'eval' => 'date',
                'default' => null,
            ],
        ],
        'datum_perma' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgzfoyer_domain_model_info.datum_perma',
            'config' => [
                'dbType' => 'date',
                'type' => 'input',
                'renderType' => 'inputDateTime',
                'size' => 12,
                'eval' => 'date',
                'default' => null,
            ],
        ],
        'hide_perma' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgzfoyer_domain_model_info.hide_perma',
            'config' => [
                'type' => 'check',
                'value' => '1'
            ]
        ],
        'infotext' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgzfoyer_domain_model_info.infotext',
            'config' => [
                'type' => 'text',
                'cols' => 40,
                'rows' => 15,
                'eval' => 'trim'
            ]
        ],
        'i_belegungen' => [
            'exclude' => false,
            'label' => 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgzfoyer_domain_model_info.i_belegungen',
            'config' => [
                'type' => 'inline',
                'foreign_table' => 'tx_sfgzfoyer_domain_model_belegung',
                'foreign_field' => 'info',
                'maxitems' => 9999,
                'appearance' => [
                    'collapseAll' => 0,
                    'levelLinksPosition' => 'top',
                    'showSynchronizationLink' => 1,
                    'showPossibleLocalizationRecords' => 1,
                    'showAllLocalizationLink' => 1
                ],
            ],

        ],
    
    ],
];
