<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Sfgz.SfgzFoyer',
            'Main',
            [
                'Info' => 'editor,vorschau,display,update',
            ],
            // non-cacheable actions
            [
                'Info' => 'editor,vorschau,display,update'
            ]
        );

        // wizards
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
            'mod {
                wizards.newContentElement.wizardItems.plugins {
                    elements {
                        main {
                            iconIdentifier = sfgz_foyer-plugin-main
                            title = LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgz_foyer_main.name
                            description = LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang_db.xlf:tx_sfgz_foyer_main.description
                            tt_content_defValues {
                                CType = list
                                list_type = sfgzfoyer_main
                            }
                        }
                    }
                    show = *
                }
        }'
        );
        
		$iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);
        $iconRegistry->registerIcon(
            'sfgz_foyer-plugin-main',
            \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
            ['source' => 'EXT:sfgz_foyer/Resources/Public/Icons/user_plugin_main.svg']
        );
		
        // Register scheduler-Tasks
        if (\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::isLoaded('scheduler')) {
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzFoyer\\Task\\CalendarImportTask'] = array(
                'extension'			=> 'SfgzFoyer',
                'title'				=> 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang.xlf:scheduler.title_import_calendar',
                'description'		=> 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang.xlf:scheduler.description_import_calendar',
                'additionalFields'	=> ''
            );
            $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Sfgz\\SfgzFoyer\\Task\\ClearbelegungTask'] = array(
                'extension'			=> 'SfgzFoyer',
                'title'				=> 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang.xlf:scheduler.title_clear',
                'description'		=> 'LLL:EXT:sfgz_foyer/Resources/Private/Language/locallang.xlf:scheduler.description_clear',
                'additionalFields'	=> ''
            );
        }

    }
);
